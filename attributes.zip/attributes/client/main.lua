RegisterNetEvent('custom:showAttributesDialog')
AddEventHandler('custom:showAttributesDialog', function()
    local input = lib.inputDialog('Set Your Attributes', {
        {type = 'number', label = 'Age', description = 'Enter your age (1-120)', required = true, min = 1, max = 120},
        {type = 'input', label = 'Details', description = 'Provide some details about your character (1-300)', required = true, min = 1, max = 300},
        {type = 'input', label = 'Outfit', description = 'Describe your outfit (1-300)', required = true, min = 1, max = 300},
    }, {
        color = {200, 50, 50} 
    })
    if input then
        local age = tonumber(input[1])
        local details = input[2] 
        local outfit = input[3] 
TriggerServerEvent('custom:saveAttributes', age, details, outfit)
    else
        TriggerEvent('chat:addMessage', {
            args = {"System", "You canceled setting your attributes."},
            color = {255, 0, 0}
        })
    end
end)
