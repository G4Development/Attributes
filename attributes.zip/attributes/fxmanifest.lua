fx_version 'cerulean'
game 'gta5'
lua54 'yes'

version '1.0.0'

shared_scripts {
    '@ox_lib/init.lua',
    '@es_extended/imports.lua',
    'config.lua',
}


client_scripts {
    'config.lua',
    'server/*.lua',
    '@es_extended/locale.lua'
}

server_scripts {
    'config.lua',
    '@oxmysql/lib/MySQL.lua',
    '@es_extended/locale.lua',
    'server/*.lua'
}

escrow_ignore {
    'config.lua'
}

dependencies {
    'ox_lib',
    'es_extended',
    'oxmysql'
}
