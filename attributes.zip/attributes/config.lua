Config = {}
Config.Commands = {
    SetAttributes = "attributes",
    ExamineAttributes = "examine"
}
