ESX = exports.es_extended:getSharedObject() 
AddEventHandler('esx:playerLoaded', function(playerId)
    local xPlayer = ESX.GetPlayerFromId(playerId)
    MySQL.Async.fetchScalar('SELECT attributes FROM users WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    }, function(attributes)
        if attributes == nil or attributes == '' then
            TriggerClientEvent('chat:addMessage', playerId, {
                args = {"System", "You have not set your attributes yet. Please set your attributes using the command /attributes [age] [details] [outfit]."},
                color = {255, 0, 0}
            })
            
        end
    end)
end)
RegisterCommand(Config.Commands.SetAttributes, function(source, args)
    if #args < 3 then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Usage: /attributes [age] [details] [outfit]"},
            color = {255, 165, 0}
        })
        return
    end

    local age = tonumber(args[1])
    local details = table.concat(args, " ", 2, #args - 1)
    local outfit = args[#args]

    if not age or age < 1 or age > 120 then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Age must be a number between 1 and 120."},
            color = {255, 0, 0}
        })
        return
    end

    if #details < 1 or #details > 100 then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Details must be between 1 and 100 characters."},
            color = {255, 0, 0}
        })
        return
    end

    if #outfit < 1 or #outfit > 100 then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Outfit must be between 1 and 100 characters."},
            color = {255, 0, 0}
        })
        return
    end

    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.execute('UPDATE users SET attributes = @attributes WHERE identifier = @identifier', {
        ['@attributes'] = json.encode({age = age, details = details, outfit = outfit}),
        ['@identifier'] = xPlayer.identifier
    })

    TriggerClientEvent('chat:addMessage', source, {
        args = {"System", "Your attributes have been set successfully."},
        color = {0, 255, 0}
    })
end, false)

TriggerEvent('chat:addSuggestion', '/' .. Config.Commands.SetAttributes, 'Set your attributes', {
    {name = 'age', help = 'Your age (1-120)'},
    {name = 'details', help = 'Details about your character (1-100 characters)'},
    {name = 'outfit', help = 'Description of your outfit (1-100 characters)'}
})

RegisterCommand(Config.Commands.ExamineAttributes, function(source, args)
    if not args[1] then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Usage: /examine [playerID]"},
            color = {255, 165, 0}
        })
        return
    end

    local targetId = tonumber(args[1])
    if not targetId then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Invalid player ID."},
            color = {255, 0, 0}
        })
        return
    end

    local targetPlayer = ESX.GetPlayerFromId(targetId)
    if not targetPlayer then
        TriggerClientEvent('chat:addMessage', source, {
            args = {"System", "Player not found."},
            color = {255, 0, 0}
        })
        return
    end

    MySQL.Async.fetchScalar('SELECT attributes FROM users WHERE identifier = @identifier', {
        ['@identifier'] = targetPlayer.identifier
    }, function(attributes)
        if attributes then
            local decodedAttributes = json.decode(attributes)
            TriggerClientEvent('chat:addMessage', source, {
                args = {"System", string.format("Player %s Attributes:\nAge: %s\nDetails: %s\nOutfit: %s", targetPlayer.name, decodedAttributes.age or "N/A", decodedAttributes.details or "N/A", decodedAttributes.outfit or "N/A")},
                color = {0, 255, 0}
            })
        else
            TriggerClientEvent('chat:addMessage', source, {
                args = {"System", "This player has not set their attributes yet."},
                color = {255, 165, 0}
            })
        end
    end)
end, false)

RegisterCommand('clearattributes', function(source, args)
    local xPlayer = ESX.GetPlayerFromId(source)
    MySQL.Async.execute('UPDATE users SET attributes = NULL WHERE identifier = @identifier', {
        ['@identifier'] = xPlayer.identifier
    })
    TriggerClientEvent('chat:addMessage', source, {
        args = {"System", "Your attributes have been cleared."},
        color = {255, 0, 0}
    })
end, false)
TriggerEvent('chat:addSuggestion', '/clearattributes', 'Clear your character\'s attributes.')
TriggerEvent('chat:addSuggestion', '/attributes', 'Set your player\'s attributes for /examine.')
TriggerEvent('chat:addSuggestion', '/examine', 'Examine any player\'s attributes.')